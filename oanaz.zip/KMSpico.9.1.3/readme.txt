this is my portable version of heldigard's incredible KMSpico
http://forums.mydigitallife.info/threads/49108-KMSpico-Official-Thread

all credits to heldigard!


1. run KMSpico.exe
2. done!


my portable version is not installing anything permanent and works full automatic.


check your activation status with "Check_Activation.cmd"
check KMSpico logfile with "Check_Log.cmd"


for a silent run use
KMSpico.exe /silent


and have fun!

nova-s :)
